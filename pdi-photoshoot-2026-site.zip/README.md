# PDI Photoshoot 2026 — production site

A static site: `index.html` holds all the content, styles and scripts, and `img/` holds the scout reference photos. It only loads fonts from Google Fonts. No build step, server or database.

## Deploy

Pick any static host and upload `index.html` and the `img/` folder to the site root, keeping the folder structure:

- **Netlify:** drag the folder onto app.netlify.com/drop.
- **Vercel:** `vercel deploy` from this folder, or import it in the dashboard.
- **GitHub Pages:** commit `index.html` to a repo, then Settings → Pages → deploy from branch.
- **Cloudflare Pages / S3 / any web server:** upload `index.html` as the root document with `img/` beside it.

## Updating content

All production info lives in one object near the top of the `<script>` block, under the comment `EDIT PRODUCTION INFO HERE`. Edit the values there (schedule, crew, shot list, wardrobe, documents) and re-upload the file.

- Status values: `"confirmed"`, `"hold"`, `"tbd"`
- Shot list rows: `[priority, "shot", "talent", "Photo" | "Video"]`, priority 1–3
- Any value containing `TBD` is shown in muted italics
- Scout photos: add files to `img/` and list them under `refs` for the matching block

## Privacy

Once deployed, anyone with the URL can see the page, including crew names. If it needs to be private, turn on password protection on your host (for example, Netlify or Vercel password protection, or Cloudflare Access).
